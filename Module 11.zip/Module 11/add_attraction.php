<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image_url = $_POST['image_url'];

    $sql = "INSERT INTO attractions (title, description, image_url) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $title, $description, $image_url);

    if ($stmt->execute()) {
        echo "New attraction added successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<form method="POST" action="add_attraction.php">
    <label>Title:</label><br>
    <input type="text" name="title" required><br>

    <label>Description:</label><br>
    <textarea name="description" required></textarea><br>

    <label>Image URL:</label><br>
    <input type="text" name="image_url" required><br>

    <button type="submit">Add Attraction</button>
</form>
