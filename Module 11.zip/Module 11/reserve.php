<?php
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $guest_name = trim($_POST['first_name']) . ' ' . trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $room_type = trim($_POST['room_type']);
    $guests = (int) $_POST['guests'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];

    $room_prices = ['Double' => 120, 'Full' => 135, 'Queen' => 150, 'King' => 160];
    $days = (strtotime($check_out) - strtotime($check_in)) / (60 * 60 * 24);
    $total_cost = $days * ($room_prices[$room_type] ?? 0);

    $stmt = $conn->prepare("INSERT INTO reservations 
        (guest_name, email, phone, room_type, guests, checkin_date, checkout_date, total_cost) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssissi", $guest_name, $email, $phone, $room_type, $guests, $check_in, $check_out, $total_cost);

    if ($stmt->execute()) {
        echo "Reservation successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>