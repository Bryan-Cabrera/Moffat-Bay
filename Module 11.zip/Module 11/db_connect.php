<?php
$host = "localhost";
$user = "root";
$password = ""; //Changed password to match what I have on my local system, -BCabrera
$database = "moffat_bay_db"; //Changed name of database to match what I have on my local system, -BCabrera

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
