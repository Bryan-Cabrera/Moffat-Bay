CREATE DATABASE moffat_bay_db; --Updated to match database name on my system -BCabrera

USE moffat_bay_db;

CREATE TABLE attractions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    image_url VARCHAR(255) NOT NULL
);

INSERT INTO attractions (title, description, image_url) VALUES
('Scenic Hiking Trails', 'Explore the beauty of nature with guided or self-paced hiking trails.', 'hiking.jpg'),
('Guided Kayaking Tours', 'Paddle through the serene waters and experience marine life.', 'kayaking.jpg'),
('Underwater Diving', 'Discover the underwater beauty of Moffat Bay.', 'snorkeling.jpg'), --Updated file name to match what's in front end code -BCabrera
('Whale Watching', 'See the majestic creatures closer then ever before.' , 'whale.jpg'); --Added line to include Whale Watching activity that Candice included in front end code -BCabrera
