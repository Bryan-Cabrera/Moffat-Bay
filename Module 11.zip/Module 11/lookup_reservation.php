<!--Bryan Cabrera, 2/25/2025, Module 11 Assignment-->
<?php
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reservation_id = trim($_POST['reservation_id']);
    $email = trim($_POST['email']);

    $sql = "SELECT * FROM reservations WHERE reservation_id = ?";
    if (!empty($email)) {
        $sql .= " AND email = ?";
    }

    $stmt = $conn->prepare($sql);
    if (!empty($email)) {
        $stmt->bind_param("is", $reservation_id, $email);
    } else {
        $stmt->bind_param("i", $reservation_id);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $reservation = $result->fetch_assoc();
        echo json_encode($reservation);
    } else {
        echo json_encode(["error" => "No reservation found."]);
    }
    $stmt->close();
}
?>