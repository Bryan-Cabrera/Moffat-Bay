<?php
//Used to fetch the latest reservation or specific one
require 'db_connect.php';

header('Content-Type: application/json');

//Check if reservation ID was provided in URL
$reservation_id = $_GET['reservation_id'] ?? null;

if ($reservation_id) {
    $stmt = $conn->prepare("SELECT * FROM reservations WHERE reservation_id = ?");
    $stmt->bind_param("i", $reservation_id);
} else {
    //Fetch most recent reservation if no ID is provided
    $stmt = $conn->prepare("SELECT * FROM reservations ORDER BY reservation_id DESC LIMIT 1");
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(["error" => "No reservation found."]);
}

$stmt->close();
?>