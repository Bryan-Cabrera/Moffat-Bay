<?php
include 'db_connect.php';

$sql = "SELECT * FROM attractions";
$result = $conn->query($sql);

$attractions = [];
while ($row = $result->fetch_assoc()) {
    $attractions[] = $row;
}

header('Content-Type: application/json');
echo json_encode($attractions);
?>
